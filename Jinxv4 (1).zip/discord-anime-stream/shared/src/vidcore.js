const SOURCES = 'https://vidrack.created.app/api/sources';
const PROVIDERS = ['vidora', 'movy', 'nova'];
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36';

export const VIDCORE_HEADERS = {
  'User-Agent': UA,
  Accept: '*/*',
  Referer: 'https://vidcore.org/',
  Origin: 'https://vidcore.org',
};

let cachedKey = null;

export function qualityRank(label) {
  const text = String(label || '');
  if (/4k/i.test(text)) return 2160;
  const n = Number((text.match(/(\d{3,4})/) || [])[1] || 0);
  return n;
}

export function isDeadStream(url, quality) {
  if (!url || !String(url).includes('sun.paleoak.top')) return false;
  return /1080/i.test(String(quality || ''));
}

export function titleMatches(query, title) {
  const want = String(query || '').trim().toLowerCase();
  const name = String(title || '').trim().toLowerCase();
  if (!want || !name) return false;
  if (name === want || name.startsWith(want)) return true;
  const words = want.split(/\s+/).filter((word) => word.length > 1);
  return words.length > 0 && words.every((word) => name.includes(word));
}

export function pickHighestVariant(playlist, baseUrl) {
  if (!String(playlist || '').includes('#EXT-X-STREAM-INF')) return baseUrl;
  const lines = String(playlist).split(/\r?\n/);
  let best = null;
  let pending = null;
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('#EXT-X-STREAM-INF')) {
      const bw = Number((trimmed.match(/BANDWIDTH=(\d+)/) || [])[1] || 0);
      const height = Number(((trimmed.match(/RESOLUTION=\d+x(\d+)/) || [])[1]) || 0);
      pending = height * 1e10 + bw;
    } else if (pending != null && trimmed && !trimmed.startsWith('#')) {
      if (!best || pending >= best.score) best = { score: pending, url: new URL(trimmed, baseUrl).href };
      pending = null;
    }
  }
  return best?.url || baseUrl;
}

async function getText(url, headers, timeout = 8000, attempts = 3) {
  let last;
  for (let n = 0; n < attempts; n++) {
    try {
      const res = await fetch(url, { headers, signal: AbortSignal.timeout(timeout) });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.text();
    } catch (err) {
      last = err;
      if (n + 1 < attempts) await new Promise((resolve) => setTimeout(resolve, 300 * (n + 1)));
    }
  }
  throw last;
}

async function getJson(url, headers, timeout) {
  return JSON.parse(await getText(url, { ...headers, Accept: 'application/json' }, timeout));
}

export async function tmdbKey(envKey) {
  if (envKey) return envKey;
  if (cachedKey) return cachedKey;
  const wrap = await getText('https://vidcore.org/embed/movie/533535', VIDCORE_HEADERS, 8000, 2);
  const iframe = (wrap.match(/src="([^"]+)"/) || [])[1];
  if (!iframe) throw new Error('Vidcore embed did not point at a player.');
  const page = await getText(iframe, VIDCORE_HEADERS, 8000, 2);
  const key = (page.match(/TMDB_KEY='([^']+)'/) || [])[1];
  if (!key) throw new Error('Could not read a TMDB key from the player.');
  cachedKey = key;
  return key;
}

function rowName(row) {
  return row.title || row.name || '';
}

export async function searchTitles(query, { apiKey, season, episode } = {}) {
  const key = await tmdbKey(apiKey);
  const trimmed = String(query || '').trim();
  if (/^\d{1,10}$/.test(trimmed)) {
    const id = Number(trimmed);
    const hits = [];
    for (const type of ['movie', 'tv']) {
      try {
        const row = await getJson(`https://api.themoviedb.org/3/${type}/${id}?api_key=${key}&language=en-US`, VIDCORE_HEADERS, 8000);
        hits.push(normaliseHit({ ...row, media_type: type }));
      } catch {
        /* try the other type */
      }
    }
    return hits.filter(Boolean);
  }
  const data = await getJson(
    `https://api.themoviedb.org/3/search/multi?api_key=${key}&language=en-US&query=${encodeURIComponent(trimmed)}`,
    VIDCORE_HEADERS,
    8000,
  );
  const want = trimmed.toLowerCase();
  return (data.results || [])
    .filter((row) => row.media_type === 'movie' || row.media_type === 'tv')
    .map((row) => {
      const name = rowName(row).toLowerCase();
      let score = Number(row.popularity) || 0;
      if (name === want) score += 100000;
      else if (name.startsWith(want)) score += 10000;
      else if (name.includes(want)) score += 1000;
      if ((season || episode) && row.media_type === 'tv') score += 5000;
      return { score, hit: normaliseHit(row) };
    })
    .filter((row) => row.hit)
    .sort((a, b) => b.score - a.score)
    .map((row) => row.hit);
}

function normaliseHit(row) {
  const title = rowName(row);
  if (!row?.id || !title) return null;
  return {
    id: row.id,
    type: row.media_type === 'tv' ? 'tv' : 'movie',
    title,
    poster: row.poster_path ? `https://image.tmdb.org/t/p/w500${row.poster_path}` : null,
  };
}

export async function captionTracks({ id, type, season, episode }) {
  const path = type === 'tv' ? `/tv/${id}/${season}/${episode}` : `/movie/${id}`;
  const hosts = type === 'tv'
    ? [`https://cache.vdrk.site/v2${path}`, `https://sub.vdrk.site/v1${path}`]
    : [`https://sub.vdrk.site/v2${path}`, `https://sub.vdrk.site/v1${path}`];
  let list = [];
  for (const url of hosts) {
    try {
      const parsed = JSON.parse(await getText(url, VIDCORE_HEADERS, 6000, 2));
      if (Array.isArray(parsed) && parsed.length) {
        list = parsed;
        break;
      }
    } catch {
      /* next host */
    }
  }
  const english = list.find((row) => /english/i.test(row.label || '') && row.file);
  if (!english) return [];
  return [{ file: english.file, label: 'English', kind: 'subtitles', default: true }];
}

export async function seasonEpisodeCount(id, season, apiKey) {
  const key = await tmdbKey(apiKey);
  const data = await getJson(
    `https://api.themoviedb.org/3/tv/${id}/season/${season}?api_key=${key}&language=en-US`,
    VIDCORE_HEADERS,
    8000,
  );
  return Array.isArray(data.episodes) ? data.episodes.length : null;
}

export async function resolveTitle({ id, type, season = 1, episode = 1, apiKey } = {}) {
  const query = type === 'tv'
    ? `id=${id}&type=tv&season=${season}&episode=${episode}`
    : `id=${id}&type=movie`;
  const found = [];
  const errors = [];
  for (const provider of PROVIDERS) {
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        const data = await getJson(`${SOURCES}/${provider}?${query}`, VIDCORE_HEADERS, 10000);
        for (const source of data.sources || []) {
          if (!source?.url || isDeadStream(source.url, source.quality)) continue;
          found.push({
            url: source.url,
            quality: source.quality || '',
            provider: source.provider || provider,
          });
        }
        break;
      } catch (err) {
        errors.push(`${provider} try ${attempt}: ${err.message}`);
      }
    }
  }
  found.sort((a, b) => qualityRank(b.quality) - qualityRank(a.quality) || a.provider.localeCompare(b.provider));
  let last = errors.join('; ') || 'No source returned a URL.';
  for (const source of found.slice(0, 6)) {
    try {
      const playlist = await getText(source.url, VIDCORE_HEADERS, 10000, 2);
      if (!playlist.includes('#EXTM3U')) throw new Error('not a playlist');
      const masterUrl = pickHighestVariant(playlist, source.url);
      const tracks = await captionTracks({ id, type, season, episode }).catch(() => []);
      return {
        masterUrl,
        headers: VIDCORE_HEADERS,
        quality: source.quality || 'max',
        provider: source.provider,
        captionTracks: tracks,
      };
    } catch (err) {
      last = `${source.provider} ${source.quality || 'auto'}: ${err.message}`;
    }
  }
  throw new Error(last);
}
