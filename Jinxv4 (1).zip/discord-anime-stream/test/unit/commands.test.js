import test from 'node:test';
import assert from 'node:assert/strict';
import { buildCommands, replaceCommands } from '../../controller/src/slash-commands.js';

test('the bot exposes stream, continue and history, without help, ping or slash stop', () => {
  const names = buildCommands('Jinx').map((cmd) => cmd.name);
  assert.deepEqual(names, ['stream', 'continue', 'history', 'streamer', 'export', 'import']);
  const stream = buildCommands('Jinx')[0].toJSON();
  assert.deepEqual(stream.options.map((o) => o.name), ['title', 'anime']);
  const title = stream.options.find((o) => o.name === 'title');
  assert.deepEqual(title.options.map((o) => o.name), ['name', 'season', 'episode']);
  assert.equal(title.options[0].required, true);
  assert.equal(title.options[1].required, false);
  const anime = stream.options.find((o) => o.name === 'anime');
  assert.equal(anime.options.find((o) => o.name === 'episode').required, false);
  const cont = buildCommands('Jinx')[1].toJSON();
  assert.equal(cont.options[0].autocomplete, true);
});

test('restart overwrites guild commands and clears the stale global list', async () => {
  const calls = [];
  const rest = {
    async put(route, { body }) {
      calls.push({ route, names: body.map((cmd) => cmd.name) });
      return body;
    },
  };
  const result = await replaceCommands(rest, {
    clientId: 'app',
    guildIds: ['guild'],
    commands: [{ name: 'help' }, { name: 'ping' }, { name: 'export' }],
  });
  assert.deepEqual(calls, [
    { route: '/applications/app/commands', names: [] },
    { route: '/applications/app/guilds/guild/commands', names: ['help', 'ping', 'export'] },
  ]);
  assert.deepEqual(result.names, ['help', 'ping', 'export']);
});
